# ELVORAX Engineering — Multi-Page Website

Industrial **mechanical theme**: dark navy steel `#0A1226` (default), safety-orange
`#FF7A1A` accents, blueprint engineering-grid overlay, hexagon bolt-head value
badges, squared machined buttons and glass panels that blur the **realistic 3D
engineering skyline** behind them (solid lit buildings with procedural lit
windows, a working tower crane, interlocking steel gears, real-time shadows and
depth fog — night city in dark mode, daylight in light mode). The ◐ toggle in
the header switches to a matching light steel theme (remembered per visitor).

- **Logo** — the authentic round badge extracted directly from the business plan PDF is now used everywhere: header, footer, floating 3D hero watermark, share image and favicons (`assets/img/logo-badge.*`, transparent original in `logo-transparent.png`). The badge art sits on a baked white disc matching the presentation's cover look, and a simplified `favicon-32.png` (EE hexagon mark) keeps the tab icon crisp at small sizes.

## v4/v5 — visibility, readability, detailed services, panel, polish

- **Readability** — brighter text (AA contrast in both themes), solid panels, 3D background dimmed behind a scrim, larger type, solid form fields with focus rings, dark text on orange buttons, no truncated descriptions.
- **Services in detail** — each of the 12 division pages has *What we provide* (5 detailed offerings), *How we deliver*, *Where we work*, *What you receive*, *Designed & installed to*, a division FAQ, a quote bar and a jump-link row.
- **Home** — new *Why Clients Choose ELVORAX* and *FAQ* sections, call / WhatsApp / directions buttons in Contact.
- **Panel** — opaque left rail, larger icons and labels, pin-to-expand button, slower auto-spotlight, spotlight hidden on short screens so all 12 divisions stay visible.
- **Professional finish** — favicon and share tags (Open Graph), LocalBusiness structured data, skip-to-content link, print styles, footer contact row, floating WhatsApp button, `index.html` redirect for hosting.

## What's new

- **Panel shortcut buttons upgraded** — the five control buttons at the foot of the rail (Pin Panel, Quick Launch, Theme, Get a Quote, Back to Top) are no longer small icon-only squares: they are full rows matching the division buttons, icon centred when the rail is collapsed and icon + name sliding in when it expands (hover, focus, quick-launch open or pinned).
- **Panel: logo head + status head removed** — the round ELVORAX badge now sits at the top of the rail (wordmark "ELVORAX / ENGINEERING" slides in beside it on hover/pin), a logo chip was added to the quick-launch flyout header, and the old SYSTEM ONLINE head (pulsing LED, rotating gear, PKT clock) is gone — the brand head now draws the separator line above the 12 division buttons. Clicking the logo returns to the home page (or scrolls to top when already there).
- **Panel clean-up (alignment + stripes)** — the orange hazard-chevron stripe that ran down the rail's inner edge and the little color bar that jumped between division buttons are both removed (the active division still shows its border + glow + pulse). The left body offset uses `safe-area-inset-left`.
- **Panel moved to the left** — the command rail is now pinned to the left edge on every page (hover-expands to the right; quick-launch flyout opens to its right). Page, header and footer offsets were flipped to match, and the rail code is now identical on all 13 pages.
- **Service-page 3D viewers replaced** — each division page now has a professional illustrated hero (blueprint grid, glowing platform, a unique line-art emblem per division, and callouts taken from that page's capabilities). Theme-aware, responsive, no WebGL needed. The home-page 3D skyline background is unchanged.
- **(earlier) 3D models fixed** — auto-framing now fits the model *and* its platform and is rotation-safe, so tall models (ELV tower, crane) and wide platforms are no longer clipped. The viewer follows the site theme (dark by default) instead of a bright white box, and mouse-wheel no longer hijacks page scrolling (use Ctrl + scroll to zoom).
- **Frontend polish** — crisp SVG theme button, header/nav spacing with the left rail, no sideways scroll on phones.

- **Left-side Command Rail** — the control panel runs as a vertical rail
  pinned to the LEFT edge of every page (no more bottom bar): the ELVORAX
  logo head, 12 direct-launch division buttons and quick controls. On desktop
  it **expands on hover** — labels slide in beside every icon (logo wordmark
  included) and the AUTO-SPOTLIGHT readout (auto-cycling divisions with a
  typewriter effect, hover to pause) appears at the bottom. The auto-cycle
  keeps glowing down the collapsed rail too. Quick controls (each shows its name
  beside the icon when the rail expands): quick-launch grid (all 12 division
  pages + home, flying out to the right of the rail with staggered card
  animation), light/dark theme toggle, quotation shortcut (scrolls to and
  pulses the quote panel) and back-to-top. On phones the rail stays a slim
  46px icon strip.
- **Realistic 3D background** — the old wireframe diorama is now a solid, lit,
  shadow-casting scene on every page: buildings with procedurally lit windows,
  a slewing tower crane with travelling trolley and hook, interlocking steel
  gears, a survey grid ground plane, exponential fog and filmic tone mapping.
  The scene follows the theme: night skyline with warm windows in dark mode,
  daylight render in light mode, with mouse/scroll parallax kept.
- **Full-screen fit** — hero pins a five-stat strip (12 divisions, 40+ fields,
  48h quote, 9 flagship projects, 95% on-time target) with animated counters to
  the bottom of the viewport, section rhythm tightened and the canvas widened
  to 1520px so content aligns edge to edge with no dead bands.
- **Divisions dropdown navigation** — on every page, the DIVISIONS button opens
  a panel with direct links to all 12 service pages (works on mobile too,
  where it becomes a full-width sheet).
- **Fast-Track Quotation panel** — the home hero carries an options panel
  (division select + name + phone + scope) that sends the enquiry straight to
  WhatsApp, filling the hero with no dead space.
- **Division panels with options** — every service card on the home page lists
  its key sub-service options as chips.
- **Theme fix** — the ◐ light-steel toggle now works on light-mode OS machines
  too (dark steel stays the default for first visits).

## Files

- `elvorax.html` — home page (styles, scripts and logo inlined)
- `services/` — 12 dedicated service pages, each with its own interactive 3D model
- `assets/img/projects/` — 110 optimised site photographs (plus `th/` thumbnails)
  used by the Signature Projects sliding gallery
- `elvorax-site.zip` — the complete site in one download, ready to host

## How to use

**To host:** upload the contents of `elvorax-site.zip` to your web server
(elvorax.html at the root, services/ and assets/ folders next to it). Rename
elvorax.html to index.html if your server expects it.

**To preview locally:** unzip and open elvorax.html in any browser — keep the
assets/ folder next to it. Styles, scripts and the logo are inlined in every
page; external dependencies are the three.js CDN (3D scenes) and the
assets/img/projects/ photos (project gallery).

## Signature Projects gallery

The home page (#projects) shows all nine delivered projects in an auto-playing,
swipeable slider with category filters (Fire Alarm & Suppression / HVAC
Ducting), a thumbnail strip and a fullscreen lightbox. The Fire Protection and
Mechanical Services pages carry the same slider filtered to their own projects:

- Fire Alarm & Suppression — GETZ Pharma, Sindh Secretariat, JP Morgan,
  Sindh Revenue Board, Trafigura, Pak Suzuki (54 photos)
- HVAC Ducting — PARCO (GI ducting), Sanofi Pharma (hi-pressure GI ducting),
  Unique Poultry (pre-insulated ducting) (56 photos)

## Pages

Home links to each division via the service cards and the hero chips:
engineering-solutions, security-surveillance, elv-systems, fire-protection,
it-network, building-automation, repair-maintenance-services,
electrical-services, mechanical-services, automobile-services, civil-works,
general-order-supplier.
